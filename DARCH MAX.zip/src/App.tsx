import { useState, useCallback, useRef, useEffect, useMemo, MouseEvent as ReactMouseEvent, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Square, 
  Circle, 
  Diamond as DiamondIcon, 
  MousePointer2, 
  Type, 
  Share2, 
  Trash2, 
  Copy, 
  Palette, 
  ChevronRight, 
  ArrowLeftRight,
  X,
  Check,
  Zap,
  Hexagon,
  Rocket,
  Database,
  ArrowDownToLine,
  Activity,
  FileText,
  UnfoldVertical,
  Maximize2,
  Minimize2,
  Link as LinkIcon
} from 'lucide-react';
import { useCanvas } from './hooks/useCanvas';
import { 
  Shape, 
  Connector, 
  Tool, 
  ShapeType, 
  ColorType, 
  DirectionType, 
  COLORS, 
  TOKENS,
  DagManifest
} from './types';

export default function App() {
  const { pan, zoom, containerRef, handleMouseDown } = useCanvas();
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [connectors, setConnectors] = useState<Connector[]>([]);
  const [tool, setTool] = useState<Tool>('select');
  const [selectedShapeId, setSelectedShapeId] = useState<string | null>(null);
  const [selectedConnId, setSelectedConnId] = useState<string | null>(null);
  const [isManifestOpen, setIsManifestOpen] = useState(false);
  const [connectSource, setConnectSource] = useState<string | null>(null);
  const [selectedLinkType, setSelectedLinkType] = useState<string>('READ_ONLY');
  const [isControlPanelCollapsed, setIsControlPanelCollapsed] = useState(false);
  const [pendingConn, setPendingConn] = useState<{ from: string, to: string } | null>(null);
  const [isToolbarOpen, setIsToolbarOpen] = useState(true);
  const [isNavOpen, setIsNavOpen] = useState(true);
  const [inspectedConnId, setInspectedConnId] = useState<string | null>(null);
  const [inspectedShapeId, setInspectedShapeId] = useState<string | null>(null);
  const [showLinkLabels, setShowLinkLabels] = useState(true);
  
  // Context Menus
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, type: 'shape' | 'conn', id: string } | null>(null);

  // Initialize with some seed data
  useEffect(() => {
    const seedShapes: Shape[] = [
      { id: 'jotform', type: 'ingest', x: 100, y: 100, w: 60, h: 60, label: 'Governor (Intent Validator)', color: 'green' },
      { id: 'wordpress', type: 'deploy', x: 800, y: 300, w: 60, h: 50, label: 'WordPress (Handoff)', color: 'purple', isLocked: true },
      { id: 'airtable', type: 'research', x: 350, y: 360, w: 60, h: 44, label: 'Airtable (State Plane)', color: 'blue' },
      { id: 'antigravity', type: 'training', x: 100, y: 440, w: 120, h: 120, label: 'AntiGravity (Operator)', color: 'red' },
    ];
    const seedConns: Connector[] = [
      { id: 'c1', fromId: 'jotform', toId: 'antigravity', dir: 'forward', operation: 'CONNECT', state: 'ACTIVE', metadata: 'READ_ONLY' },
      { id: 'c2', fromId: 'antigravity', toId: 'airtable', dir: 'both', operation: 'MERGE', state: 'ACTIVE', metadata: 'READ_WRITE' },
      { id: 'c4', fromId: 'antigravity', toId: 'wordpress', dir: 'both', operation: 'CONNECT', state: 'ACTIVE', metadata: 'HANDOFF' },
    ];
    setShapes(seedShapes);
    setConnectors(seedConns);
  }, []);

  // --- Actions ---
  const addShape = useCallback((type: ShapeType, x?: number, y?: number) => {
    const id = Math.random().toString(36).substr(2, 9);
    
    // Default to center of viewport relative to pan/zoom if coords not provided
    const targetX = x !== undefined ? x : (-pan.x + window.innerWidth / 2) / zoom - 60;
    const targetY = y !== undefined ? y : (-pan.y + window.innerHeight / 2) / zoom - 22;

    let color: ColorType = 'blue';
    let label = 'Research Phase';
    if (type === 'ingest') { color = 'green'; label = 'Data Ingest'; }
    if (type === 'training') { color = 'red'; label = 'Model Training'; }
    if (type === 'deploy') { color = 'purple'; label = 'Deploy'; }

    const newShape: Shape = {
      id,
      type,
      x: targetX,
      y: targetY,
      w: type === 'training' ? TOKENS.NODES.DIAMOND_SIZE : TOKENS.NODES.DEFAULT_W,
      h: type === 'training' ? TOKENS.NODES.DIAMOND_SIZE : TOKENS.NODES.DEFAULT_H,
      label,
      color,
    };
    setShapes(prev => [...prev, newShape]);
    setSelectedShapeId(id);
    setTool('select');
  }, [pan, zoom]);

  const deleteShape = useCallback((id: string) => {
    setShapes(prev => prev.filter(s => s.id !== id));
    setConnectors(prev => prev.filter(c => c.fromId !== id && c.toId !== id));
    if (selectedShapeId === id) setSelectedShapeId(null);
  }, [selectedShapeId]);

  const duplicateShape = useCallback((id: string) => {
    const s = shapes.find(sh => sh.id === id);
    if (!s) return;
    const nid = Math.random().toString(36).substr(2, 9);
    const ns: Shape = { ...s, id: nid, x: s.x + 30, y: s.y + 30, label: s.label + ' (copy)' };
    setShapes(prev => [...prev, ns]);
    setSelectedShapeId(nid);
  }, [shapes]);

  const updateShapeColor = useCallback((id: string, color: ColorType) => {
    setShapes(prev => prev.map(s => s.id === id ? { ...s, color } : s));
  }, []);

  const updateShapeLabel = useCallback((id: string, label: string) => {
    setShapes(prev => prev.map(s => s.id === id ? { ...s, label } : s));
  }, []);

  const toggleLockShape = useCallback((id: string) => {
    setShapes(prev => prev.map(s => s.id === id ? { ...s, isLocked: !s.isLocked } : s));
  }, []);

  const addConnector = useCallback((fromId: string, toId: string) => {
    if (fromId === toId) return;
    if (connectors.find(c => (c.fromId === fromId && c.toId === toId) || (c.fromId === toId && c.toId === fromId))) return;
    const id = 'c' + Math.random().toString(36).substr(2, 7);
    
    // Auto-configure based on selected link type from control panel
    let dir: DirectionType = 'forward';
    if (selectedLinkType === 'READ_WRITE' || selectedLinkType === 'HANDOFF') dir = 'both';

    setConnectors(prev => [...prev, { 
      id, 
      fromId, 
      toId, 
      dir, 
      operation: 'CONNECT', 
      state: 'ACTIVE',
      metadata: selectedLinkType as any
    }]);
    setSelectedConnId(id);
  }, [connectors, selectedLinkType]);

  const deleteConn = useCallback((id: string) => {
    setConnectors(prev => prev.filter(c => c.id !== id));
    if (selectedConnId === id) setSelectedConnId(null);
  }, [selectedConnId]);

  const updateConnContract = useCallback((id: string, updates: Partial<Connector>) => {
    setConnectors(prev => prev.map(c => {
      if (c.id === id) {
        const next = { ...c, ...updates };
        // Integrity Check
        if (next.dir === 'both' && (!next.sourceBinding || !next.targetBinding)) {
          next.state = 'ERROR';
          next.errorMessage = 'BIDIRECTIONAL FLOW REQUIRES DUAL BINDING';
        } else {
          next.state = 'ACTIVE';
          next.errorMessage = undefined;
        }
        return next;
      }
      return c;
    }));
  }, []);

  // --- Serialization Contract (.dag) ---
  const doCommit = useCallback(() => {
    const hasErrors = connectors.some(c => c.state === 'ERROR');
    if (hasErrors) {
      alert('COMMIT REJECTED: VALIDATE RED CONTRACTS BEFORE SERIALIZATION');
      return;
    }

    const manifest: DagManifest = {
      version: '1.0.0',
      engineStatus: 'NOMINAL',
      nodes: shapes.map(s => ({
        id: s.id,
        type: s.type,
        label: s.label,
        contract: { color: s.color },
        spatial: { x: s.x, y: s.y, w: s.w, h: s.h }
      })),
      edges: connectors.map(c => ({
        id: c.id,
        source: c.fromId,
        target: c.toId,
        config: { 
          direction: c.dir,
          operation: c.operation,
          state: c.state,
          sourceBinding: c.sourceBinding || 'DEFAULT',
          targetBinding: c.targetBinding || 'DEFAULT'
        }
      })),
      timestamp: new Date().toISOString()
    };
    console.log('--- .DAG MANIFEST GENERATED ---');
    console.log(JSON.stringify(manifest, null, 2));
    alert('HARDENED_DAG_COMMITTED: System State Persistent Across Kernel Layer');
  }, [shapes, connectors]);

  const handleCanvasClick = (e: ReactMouseEvent) => {
    if (e.target !== containerRef.current && !(e.target as HTMLElement).classList.contains('world')) return;
    
    if (tool !== 'select' && tool !== 'connect') {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const x = (e.clientX - rect.left - pan.x) / zoom - 60;
      const y = (e.clientY - rect.top - pan.y) / zoom - 22;
      addShape(tool as ShapeType, x, y);
    } else {
      setSelectedShapeId(null);
      setSelectedConnId(null);
      setConnectSource(null);
    }
    setContextMenu(null);
  };

  const onShapeMouseDown = (e: ReactMouseEvent, id: string) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    setContextMenu(null);

    if (tool === 'connect') {
      if (!connectSource) {
        setConnectSource(id);
      } else {
        if (connectSource !== id) {
          setPendingConn({ from: connectSource, to: id });
        }
        setConnectSource(null);
      }
      return;
    }

    setSelectedShapeId(id);
    setSelectedConnId(null);

    const s = shapes.find(sh => sh.id === id);
    if (!s || s.isLocked) return;

    const startX = e.clientX;
    const startY = e.clientY;
    const initialX = s.x;
    const initialY = s.y;

    const onMouseMove = (moveEvent: globalThis.MouseEvent) => {
      const dx = (moveEvent.clientX - startX) / zoom;
      const dy = (moveEvent.clientY - startY) / zoom;
      
      const rawX = initialX + dx;
      const rawY = initialY + dy;
      
      const snap = 24;
      const snappedX = Math.round(rawX / snap) * snap;
      const snappedY = Math.round(rawY / snap) * snap;

      setShapes(prev => prev.map(sh => sh.id === id ? { ...sh, x: snappedX, y: snappedY } : sh));
    };

    const onMouseUp = () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  const onResizeMouseDown = (e: ReactMouseEvent, id: string) => {
    e.stopPropagation();
    const s = shapes.find(sh => sh.id === id);
    if (!s || s.isLocked) return;

    const startX = e.clientX;
    const startY = e.clientY;
    const startW = s.w;
    const startH = s.h;

    const onMouseMove = (moveEvent: globalThis.MouseEvent) => {
      const dw = (moveEvent.clientX - startX) / zoom;
      const dh = (moveEvent.clientY - startY) / zoom;
      const snap = 24;
      const rawW = Math.max(72, startW + dw);
      const rawH = Math.max(24, startH + dh);
      const snappedW = Math.round(rawW / snap) * snap;
      const snappedH = Math.round(rawH / snap) * snap;
      
      setShapes(prev => prev.map(sh => sh.id === id ? { ...sh, w: snappedW, h: snappedH } : sh));
    };

    const onMouseUp = () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  // --- Geometry Helpers ---
  const portCenter = useCallback((shape: Shape, side: 'top' | 'bottom' | 'left' | 'right') => {
    const cx = shape.x + shape.w / 2;
    const cy = shape.y + shape.h / 2;
    switch (side) {
      case 'top': return { x: cx, y: shape.y };
      case 'bottom': return { x: cx, y: shape.y + shape.h };
      case 'left': return { x: shape.x, y: cy };
      case 'right': return { x: shape.x + shape.w, y: cy };
    }
  }, []);

  const getBestPorts = useCallback((from: Shape, to: Shape) => {
    const dx = (to.x + to.w/2) - (from.x + from.w/2);
    const dy = (to.y + to.h/2) - (from.y + from.h/2);
    if (Math.abs(dx) > Math.abs(dy)) {
      return dx > 0 ? { f: 'right', t: 'left' } : { f: 'left', t: 'right' };
    } else {
      return dy > 0 ? { f: 'bottom', t: 'top' } : { f: 'top', t: 'bottom' };
    }
  }, []);

  // --- Rendering Helpers ---
  const renderConnector = (conn: Connector) => {
    const from = shapes.find(s => s.id === conn.fromId);
    const to = shapes.find(s => s.id === conn.toId);
    if (!from || !to) return null;

    const { f, t } = getBestPorts(from, to);
    const p1 = portCenter(from, f as any);
    const p2 = portCenter(to, t as any);

    // Dynamic routing with curvature to avoid direct node intersection
    const midX = p1.x + (p2.x - p1.x) / 2;
    const midY = p1.y + (p2.y - p1.y) / 2;
    const curveBoost = Math.abs(p1.y - p2.y) < 50 ? 50 : 0;
    const d = `M${p1.x},${p1.y} C${midX},${p1.y - curveBoost} ${midX},${p2.y + curveBoost} ${p2.x},${p2.y}`;

    const selected = selectedConnId === conn.id;
    const isError = conn.state === 'ERROR';

    // Activity color mapping
    const activity = conn.metadata;
    const metaColorMap: Record<string, ColorType> = {
      'READ_ONLY': 'green',
      'WRITE_ONLY': 'amber',
      'READ_WRITE': 'red',
      'HANDOFF': 'purple'
    };
    const activeColor = metaColorMap[activity || ''] || from.color;
    let strokeColor = COLORS[activeColor].hex;

    if (selected) strokeColor = TOKENS.UI.HIGHLIGHT_CSS;
    if (isError) strokeColor = "#ef4444";

    // Text position for manifest decal
    const midX_text = p1.x + (p2.x - p1.x) / 2;
    const midY_text = p1.y + (p2.y - p1.y) / 2 - (Math.abs(p1.y - p2.y) < 50 ? 50 : 0);

    // CSS Animation Classes
    const logicClasses = [
      'connector-line',
      selected ? 'connector-line-selected' : '',
      conn.state === 'PENDING' ? 'marching-ants' : '',
      (activity === 'READ_WRITE' || activity === 'HANDOFF') ? 'connector-glow' : '',
      (activity === 'HANDOFF') ? 'connector-pulse' : '',
    ].filter(Boolean).join(' ');

    return (
      <g 
        key={conn.id} 
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setContextMenu({ x: e.clientX, y: e.clientY, type: 'conn', id: conn.id });
        }}
        onDoubleClick={(e) => {
          e.stopPropagation();
          setInspectedConnId(conn.id);
        }}
      >
        <path 
          d={d} 
          className="connector-hit" 
          onClick={(e) => {
            e.stopPropagation();
            setSelectedConnId(conn.id);
            setSelectedShapeId(null);
          }}
        />
        <path 
          d={d} 
          className={logicClasses}
          style={{ 
            stroke: strokeColor,
            strokeWidth: selected ? TOKENS.EDGES.ACTIVE_STROKE_WIDTH : TOKENS.EDGES.STROKE_WIDTH,
            opacity: selected || isError ? 1 : TOKENS.EDGES.OPACITY,
            markerEnd: (conn.dir === 'forward' || conn.dir === 'both') ? `url(#arrow-end${selected ? '-sel' : `-${activeColor}`})` : undefined,
          }}
        />

        {/* --- Activity Decal --- */}
        {showLinkLabels && (
          <g transform={`translate(${midX_text},${midY_text})`}>
            <rect 
              x="-30" y="-8" width="60" height="16" 
              fill="black" 
              rx="2" 
              className="opacity-90"
            />
            <text 
              textAnchor="middle" 
              dy="3" 
              fill="white" 
              className="text-[8px] font-black uppercase tracking-widest pointer-events-none"
            >
              {activity || 'LINK'}
            </text>
          </g>
        )}

        {/* --- DARCH FLOW PARTICLES --- */}
        {(activity === 'WRITE_ONLY') && (
          <g>
            {[0, 1, 2].map((i) => (
              <circle key={`fwd-${i}`} r="3" fill={strokeColor} className="flow-particle shadow-sm">
                <animateMotion 
                  dur={`${1.2 + i * 0.4}s`} 
                  repeatCount="indefinite" 
                  path={d}
                  begin={`${-i * 0.4}s`}
                />
              </circle>
            ))}
          </g>
        )}

        {(activity === 'HANDOFF') && (
          <g>
            {[0, 1].map((i) => (
              <circle key={`ho-fwd-${i}`} r="2.5" fill={strokeColor} className="flow-particle opacity-80">
                <animateMotion 
                  dur="2.2s" 
                  repeatCount="indefinite" 
                  path={d}
                  begin={`${-i * 1.1}s`}
                />
              </circle>
            ))}
            {[0, 1].map((i) => (
              <circle key={`ho-rev-${i}`} r="2.5" fill={strokeColor} className="flow-particle opacity-80">
                <animateMotion 
                  dur="2.2s" 
                  repeatCount="indefinite" 
                  path={d}
                  begin={`${-i * 1.1 + 1.1}s`}
                  keyPoints="1;0"
                  keyTimes="0;1"
                  calcMode="linear"
                />
              </circle>
            ))}
          </g>
        )}
      </g>
    );
  };

  // --- Keyboard Shortcuts ---
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setTool('select');
        setConnectSource(null);
        setSelectedShapeId(null);
        setSelectedConnId(null);
        setContextMenu(null);
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && document.activeElement === document.body) {
        if (selectedShapeId) deleteShape(selectedShapeId);
        if (selectedConnId) deleteConn(selectedConnId);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [selectedShapeId, selectedConnId, deleteShape, deleteConn]);

  return (
    <div className="relative w-full h-screen overflow-hidden select-none bg-[#F2F0EB] border-[12px] border-white flex flex-col font-sans">
      {/* --- Top Navigation --- */}
      <nav className="h-20 border-b border-[#1A1A1A]/10 flex items-center justify-between px-12 z-50 bg-[#F2F0EB]">
        <div className="flex items-baseline text-[#1A1A1A]">
          <span className="text-4xl font-black tracking-tighter">DARCH</span>
          <div className="hidden lg:flex flex-col ml-6 border-l-2 border-[#1A1A1A]/10 pl-4">
            <span className="text-[9px] font-black tracking-widest text-[#1A1A1A]/40 uppercase leading-none">
              Airtable is the <span className="text-[#1A1A1A]/80">Shared State Plane</span>
            </span>
            <span className="text-[9px] font-black tracking-widest text-[#1A1A1A]/40 uppercase mt-1">
              WordPress is the <span className="text-[#1A1A1A]/80">Handoff Surface</span>
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className={`flex items-center gap-3 overflow-hidden transition-all duration-300 ${isNavOpen ? 'w-[170px] opacity-100' : 'w-0 opacity-0'}`}>
            <span className="w-8 h-8 rounded-full border-2 border-[#1A1A1A] text-[#1A1A1A] flex items-center justify-center font-black text-[11px] cursor-pointer hover:bg-[#1A1A1A] hover:text-white transition-colors flex-shrink-0">N</span>
            <span className="w-8 h-8 rounded-full border-2 border-[#1A1A1A] text-[#1A1A1A] flex items-center justify-center font-black text-[11px] cursor-pointer hover:bg-[#1A1A1A] hover:text-white transition-colors flex-shrink-0">L</span>
            <span className="w-8 h-8 rounded-full border-2 border-[#1A1A1A] text-[#1A1A1A] flex items-center justify-center font-black text-[11px] cursor-pointer hover:bg-[#1A1A1A] hover:text-white transition-colors flex-shrink-0">F</span>
            <span onClick={doCommit} className="w-8 h-8 rounded-full bg-[#FF4D00] text-white flex items-center justify-center cursor-pointer hover:scale-105 transition-transform flex-shrink-0" title="Commit DAG">
              <Check size={16} strokeWidth={3} />
            </span>
          </div>
          <button onClick={() => setIsNavOpen(!isNavOpen)} className="w-8 h-8 flex items-center justify-center hover:bg-black/5 rounded-full text-[#1A1A1A] transition-colors flex-shrink-0">
            <ChevronRight className={`transition-transform duration-300 ${isNavOpen ? '' : 'rotate-180'}`} size={16} />
          </button>
        </div>
      </nav>

      <div className="flex-1 flex relative overflow-hidden">
        {/* --- Canvas Manifest Panel --- */}
        <AnimatePresence>
          {isManifestOpen && (
            <motion.div
              initial={{ x: -320 }}
              animate={{ x: 0 }}
              exit={{ x: -320 }}
              className="absolute left-0 top-0 bottom-0 w-80 bg-white border-r-4 border-black z-[45] flex flex-col shadow-2xl"
            >
              <div className="p-6 bg-black text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Activity size={18} />
                  <span className="font-black uppercase tracking-tighter italic">Canvas_Manifest</span>
                </div>
                <button onClick={() => setIsManifestOpen(false)}><X size={18} /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-6">
                <div className="space-y-2">
                  <div className="text-[10px] font-black uppercase opacity-40">Active_Nodes ({shapes.length})</div>
                  <div className="grid gap-2">
                    {shapes.map(s => (
                      <div key={s.id} className="p-3 bg-black/5 border-l-4 border-black flex items-center justify-between group">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black uppercase">{s.label}</span>
                          <span className="text-[8px] opacity-40">ID: {s.id}</span>
                        </div>
                        <button onClick={() => setSelectedShapeId(s.id)} className="opacity-0 group-hover:opacity-100 transition-opacity">
                          <MousePointer2 size={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-[10px] font-black uppercase opacity-40">Active_Links ({connectors.length})</div>
                  <div className="grid gap-2">
                    {connectors.map(c => {
                      const from = shapes.find(s => s.id === c.fromId);
                      const to = shapes.find(s => s.id === c.toId);
                      return (
                        <div key={c.id} className="p-3 bg-black/5 border-l-4 border-black space-y-1">
                          <div className="flex items-center justify-between text-[10px] font-black">
                            <span className="text-[#FF4D00]">{c.metadata || 'LINK'}</span>
                            <span className="opacity-40">{c.operation}</span>
                          </div>
                          <div className="text-[9px] flex items-center gap-2">
                            <span className="uppercase">{from?.label.substring(0, 8)}...</span>
                            <ArrowLeftRight size={10} className="opacity-20" />
                            <span className="uppercase">{to?.label.substring(0, 8)}...</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        {/* --- Left Sidebar & Collaborative Toolbar --- */}
        <div className={`border-r border-[#1A1A1A]/10 flex flex-col items-center bg-[#F2F0EB] z-40 transition-all duration-300 ${isToolbarOpen ? 'w-20' : 'w-10'}`}>
          <button 
            onClick={() => setIsToolbarOpen(!isToolbarOpen)} 
            className="mt-4 mb-2 p-2 hover:bg-black/5 rounded text-[#1A1A1A] transition-colors"
          >
            <ChevronRight className={`transition-transform duration-300 ${isToolbarOpen ? 'rotate-180' : ''}`} size={16} />
          </button>
          
          <div className={`flex flex-col gap-1.5 w-full px-2 overflow-hidden transition-all duration-300 ${isToolbarOpen ? 'opacity-100 max-h-[600px]' : 'opacity-0 max-h-0'}`}>
            <ToolbarButton active={isManifestOpen} onClick={() => setIsManifestOpen(!isManifestOpen)} icon={<Activity size={16} />} label="Manifest" />
            <div className="h-px bg-[#1A1A1A]/10 mx-2 my-1" />
            <ToolbarButton active={tool === 'research'} onClick={() => setTool('research')} icon={<Square size={16} />} label="Research" />
        <ToolbarButton active={tool === 'ingest'} onClick={() => setTool('ingest')} icon={<Circle size={16} />} label="Ingest" />
        <ToolbarButton active={tool === 'training'} onClick={() => setTool('training')} icon={<Square size={16} />} label="Train" />
        <ToolbarButton active={tool === 'deploy'} onClick={() => setTool('deploy')} icon={<Hexagon size={16} />} label="Deploy" />
        <div className="h-px bg-[#1A1A1A]/10 mx-2 my-1" />
        <ToolbarButton active={tool === 'connect'} onClick={() => setTool('connect')} icon={<Share2 size={16} />} label="Connect" />
        <div className="h-px bg-[#1A1A1A]/10 mx-2 my-1" />
        <ToolbarButton active={tool === 'select'} onClick={() => setTool('select')} icon={<MousePointer2 size={16} />} label="Select" />
        <div className="h-px bg-[#1A1A1A]/10 mx-2 my-1" />
        <button 
          onClick={() => { setShapes([]); setConnectors([]); }}
          className="p-2 transition-colors rounded-lg hover:bg-red-50 text-red-500 flex justify-center w-full"
        >
          <X size={16} />
        </button>
      </div>

          {!isToolbarOpen && (
            <div className="flex-1 flex flex-col justify-center">
              <span className="rotate-[-90deg] whitespace-nowrap text-[10px] font-black tracking-[0.3em] uppercase text-[#1A1A1A]/30">
                STABILITY_OK
              </span>
            </div>
          )}
        </div>

        {/* --- Main Content Area --- */}
        <div className="flex-1 relative flex">
          {/* --- Canvas --- */}
          <div 
            ref={containerRef}
            onMouseDown={handleMouseDown}
            onClick={handleCanvasClick}
            className={`flex-1 relative overflow-hidden bg-[#2a2c2d] ${tool === 'connect' ? 'cursor-crosshair' : 'cursor-default'}`}
          >
            {/* Grid that doesn't disappear on zoom */}
            <div 
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(circle, rgba(255, 255, 255, 0.35) 1px, transparent 1px)',
                backgroundSize: `${24 * zoom}px ${24 * zoom}px`,
                backgroundPosition: `${pan.x - 12 * zoom}px ${pan.y - 12 * zoom}px`
              }}
            />

            <div 
              className="world pointer-events-none" 
              style={{ 
                width: 5000, 
                height: 5000, 
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                transformOrigin: '0 0'
              }}
            >
              
              <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
                <defs>
                  <marker id="arrow-end" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto">
                    <path d="M0,0 L0,10 L10,5 z" fill="#94a3b8" opacity="0.8"/>
                  </marker>
                  <marker id="arrow-end-sel" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto">
                    <path d="M0,0 L0,10 L10,5 z" fill="#FF4D00"/>
                  </marker>
                  {/* Colored Markers */}
                  {(Object.keys(COLORS) as ColorType[]).map(c => (
                    <marker key={`arrow-end-${c}`} id={`arrow-end-${c}`} markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto">
                      <path d="M0,0 L0,10 L10,5 z" fill={COLORS[c].hex} opacity="0.8"/>
                    </marker>
                  ))}
                </defs>
                {connectors.map(renderConnector)}
              </svg>

              {shapes.map(s => (
                <DiagramShape 
                  key={s.id}
                  shape={s}
                  selected={selectedShapeId === s.id}
                  connecting={connectSource === s.id}
                  onMouseDown={(e: ReactMouseEvent) => onShapeMouseDown(e, s.id)}
                  onResizeMouseDown={(e: ReactMouseEvent) => onResizeMouseDown(e, s.id)}
                  onLabelChange={(val: string) => updateShapeLabel(s.id, val)}
                  onDoubleClick={() => setInspectedShapeId(s.id)}
                  onContextMenu={(e: ReactMouseEvent) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setContextMenu({ x: e.clientX, y: e.clientY, type: 'shape', id: s.id });
                  }}
                />
              ))}
            </div>
          </div>

          {/* --- Right Specs Panel --- */}
          <div className="hidden lg:block w-80 border-l border-[#1A1A1A]/10 bg-white/30 backdrop-blur-md relative overflow-hidden z-40">
            <div className="p-8 border-b border-[#1A1A1A]/10">
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#1A1A1A]/40 mb-6 underline">Engine Status</div>
              {selectedConnId ? (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-black uppercase text-[#1A1A1A]/40">Edge_ID</span>
                    <span className="font-mono text-xs font-bold">{selectedConnId}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Operation Contract</div>
                    <select 
                      className="w-full bg-[#1A1A1A] text-white p-2 text-[10px] font-black uppercase tracking-widest outline-none"
                      value={connectors.find(c => c.id === selectedConnId)?.operation}
                      onChange={(e) => updateConnContract(selectedConnId, { operation: e.target.value as any })}
                    >
                      <option value="CONNECT">PASS_THROUGH</option>
                      <option value="MERGE">MERGE_CONTRACT</option>
                      <option value="APPEND">APPEND_LIST</option>
                      <option value="OVERRIDE">STATE_OVERRIDE</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Flow Policy</div>
                    <div className="grid grid-cols-3 gap-2">
                      <button 
                        onClick={() => updateConnContract(selectedConnId, { dir: 'forward' })}
                        className={`p-2 text-[10px] font-black border ${connectors.find(c => c.id === selectedConnId)?.dir === 'forward' ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]' : 'border-[#1A1A1A]/20'}`}
                      >
                        UNI
                      </button>
                      <button 
                        onClick={() => updateConnContract(selectedConnId, { dir: 'both' })}
                        className={`p-2 text-[10px] font-black border ${connectors.find(c => c.id === selectedConnId)?.dir === 'both' ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]' : 'border-[#1A1A1A]/20'}`}
                      >
                        BI
                      </button>
                      <button 
                        onClick={() => updateConnContract(selectedConnId, { dir: 'association' })}
                        className={`p-2 text-[8px] font-black border ${connectors.find(c => c.id === selectedConnId)?.dir === 'association' ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]' : 'border-[#1A1A1A]/20'}`}
                      >
                        ASSOC
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="text-[10px] font-black uppercase opacity-40">Connection Metadata</div>
                    <input 
                      placeholder="METADATA_LABEL" 
                      className="w-full bg-transparent border-b border-[#1A1A1A]/20 p-1 text-[10px] font-mono outline-none focus:border-[#FF4D00]"
                      value={connectors.find(c => c.id === selectedConnId)?.metadata || ''}
                      onChange={(e) => updateConnContract(selectedConnId, { metadata: e.target.value })}
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="text-[10px] font-black uppercase opacity-40">Property Binding</div>
                    <input 
                      placeholder="SRC_PROP_KEY" 
                      className="w-full bg-transparent border-b border-[#1A1A1A]/20 p-1 text-[10px] font-mono outline-none focus:border-[#FF4D00]"
                      value={connectors.find(c => c.id === selectedConnId)?.sourceBinding || ''}
                      onChange={(e) => updateConnContract(selectedConnId, { sourceBinding: e.target.value })}
                    />
                    <input 
                      placeholder="TGT_PROP_KEY" 
                      className="w-full bg-transparent border-b border-[#1A1A1A]/20 p-1 text-[10px] font-mono outline-none focus:border-[#FF4D00]"
                      value={connectors.find(c => c.id === selectedConnId)?.targetBinding || ''}
                      onChange={(e) => updateConnContract(selectedConnId, { targetBinding: e.target.value })}
                    />
                  </div>

                  {connectors.find(c => c.id === selectedConnId)?.errorMessage && (
                    <div className="p-3 bg-red-500 text-white text-[9px] font-black leading-tight uppercase tracking-widest animate-pulse">
                      {connectors.find(c => c.id === selectedConnId)?.errorMessage}
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4 opacity-40">
                  <SpecItem label="Accuracy" value="100%" />
                  <div className="w-full h-[2px] bg-[#1A1A1A]/5 mt-1">
                    <div className="w-full h-full bg-[#1A1A1A]" />
                  </div>
                  <SpecItem label="Nodes" value={shapes.length.toString()} />
                  <SpecItem label="Links" value={connectors.length.toString()} />
                </div>
              )}
            </div>
            
            <div className="p-8">
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#1A1A1A]/40 mb-4">Matrix State</div>
              <div className="grid grid-cols-4 gap-2">
                {shapes.slice(0, 8).map(s => (
                  <div key={s.id} className={`aspect-square border border-[#1A1A1A]/20 ${COLORS[s.color].bg}`} />
                ))}
                {Array.from({ length: Math.max(0, 8 - shapes.length) }).map((_, i) => (
                  <div key={i} className="aspect-square border border-[#1A1A1A]/5" />
                ))}
              </div>
            </div>

            <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#1A1A1A] text-white space-y-2">
              <div className="text-[9px] uppercase tracking-widest opacity-50">Operational Logs</div>
              <div className="font-mono text-[9px] opacity-80 leading-relaxed uppercase">
                &gt; V8_ENGINE: ACTIVE<br/>
                &gt; ERRORS: {connectors.filter(c => c.state === 'ERROR').length}<br/>
                &gt; PENDING: {connectors.filter(c => c.state === 'PENDING').length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* --- Footer --- */}
      <footer className="h-8 border-t border-[#1A1A1A]/10 flex items-center px-12 justify-between z-50 bg-[#F2F0EB]">
        <div className="text-[10px] font-black uppercase tracking-[0.1em] text-[#1A1A1A]/60">&copy; 2026_STUDIO_FLOWCHART</div>
      </footer>

      {/* --- Context Menu --- */}
      <AnimatePresence>
        {contextMenu && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed z-[100] bg-white border border-gray-200 rounded-xl shadow-2xl py-1.5 min-w-[180px]"
            style={{ left: contextMenu.x, top: contextMenu.y }}
          >
            {contextMenu.type === 'shape' ? (
              <>
                <div className="px-3 py-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Shape</div>
                <ContextItem icon={<Type size={14} />} label="Rename" onClick={() => {
                  setContextMenu(null);
                  setSelectedShapeId(contextMenu.id);
                  // Trigger manually if needed, but we keep setIsEditing internal
                }} />
                <ContextItem 
                  icon={shapes.find(s => s.id === contextMenu.id)?.isLocked ? <Maximize2 size={14} /> : <Minimize2 size={14} />} 
                  label={shapes.find(s => s.id === contextMenu.id)?.isLocked ? "Unlock" : "Lock"} 
                  onClick={() => { toggleLockShape(contextMenu.id); setContextMenu(null); }} 
                />
                <ContextItem icon={<Share2 size={14} />} label="Inspect" onClick={() => { setInspectedShapeId(contextMenu.id); setContextMenu(null); }} />
                <ContextItem icon={<Copy size={14} />} label="Duplicate" onClick={() => duplicateShape(contextMenu.id)} />
                <div className="h-px bg-gray-100 my-1" />
                <ContextItem icon={<Trash2 size={14} />} label="Delete" variant="danger" onClick={() => { deleteShape(contextMenu.id); setContextMenu(null); }} />
              </>
            ) : (
              <>
                <div className="px-3 py-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Connector</div>
                <ContextItem icon={<ChevronRight size={14} />} label="Set Contract" onClick={() => { setSelectedConnId(contextMenu.id); setContextMenu(null); }} />
                <div className="h-px bg-gray-100 my-1" />
                <ContextItem icon={<Trash2 size={14} />} label="Delete" variant="danger" onClick={() => { deleteConn(contextMenu.id); setContextMenu(null); }} />
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Connection Confirmation --- */}
      <AnimatePresence>
        {pendingConn && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-32 left-1/2 -translate-x-1/2 z-50 bg-white border-2 border-[#1A1A1A] rounded-full p-2 flex items-center gap-4 shadow-2xl"
          >
            <span className="pl-4 text-[10px] font-black uppercase tracking-widest text-[#1A1A1A]">Confirm Link?</span>
            <div className="flex gap-1">
              <button 
                onClick={() => { addConnector(pendingConn.from, pendingConn.to); setPendingConn(null); }}
                className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white hover:bg-green-600 transition-colors"
                title="Confirm"
              >
                <Check size={20} />
              </button>
              <button 
                onClick={() => setPendingConn(null)}
                className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors"
                title="Cancel"
              >
                <X size={20} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- DARCH_CONTROL CENTER (Floating Modal) --- */}
      <motion.div 
        drag
        dragMomentum={false}
        initial={{ x: '50%', y: -100 }}
        style={{ left: '50%', translateX: '-50%' }}
        className="fixed bottom-8 z-[60] flex flex-col items-center"
      >
        <div className="bg-white border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,0.3)] min-w-[420px]">
          {/* Header/Handle */}
          <div className="bg-black text-white p-2 flex justify-between items-center cursor-move">
            <span className="text-[9px] font-black uppercase tracking-widest px-2 italic">DARCH_Control_V1.1</span>
            <div className="flex gap-2">
              <button 
                onClick={() => setShowLinkLabels(!showLinkLabels)} 
                className={`p-1 hover:text-[#FF4D00] transition-colors ${showLinkLabels ? 'text-[#FF4D00]' : 'text-white/40'}`}
                title="Toggle Link Labels"
              >
                <FileText size={14} />
              </button>
              <button onClick={() => setIsControlPanelCollapsed(!isControlPanelCollapsed)} className="hover:text-[#FF4D00]">
                {isControlPanelCollapsed ? <Maximize2 size={14} /> : <Minimize2 size={14} />}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {!isControlPanelCollapsed && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden bg-[#F2F0EB]"
              >
                <div className="flex border-b-2 border-black/10">
                  <button 
                    onClick={() => setTool('ingest')} // Just a fallback to nodes tab
                    className={`flex-1 p-3 text-[10px] font-black uppercase tracking-widest transition-colors ${tool !== 'connect' ? 'bg-black text-white' : 'hover:bg-black/5'}`}
                  >
                    Nodes
                  </button>
                  <button 
                    onClick={() => { setTool('connect'); }}
                    className={`flex-1 p-3 text-[10px] font-black uppercase tracking-widest transition-colors ${tool === 'connect' ? 'bg-black text-white' : 'hover:bg-black/5'}`}
                  >
                    Links
                  </button>
                </div>

                <div className="p-6">
                  {tool !== 'connect' ? (
                    <div className="flex items-center justify-around gap-4">
                      <div className="flex flex-col items-center gap-1">
                        <button 
                          onClick={() => addShape('ingest')}
                          className="w-12 h-12 rounded-full bg-black border-4 border-[#10B981] hover:scale-110 transition-transform shadow-lg flex items-center justify-center text-white"
                        >
                          <ArrowDownToLine size={20} />
                        </button>
                        <span className="text-[9px] font-black opacity-60 uppercase">Ingest</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <button 
                          onClick={() => addShape('research')}
                          className="w-14 h-12 rounded-md bg-black border-4 border-[#3B82F6] hover:scale-110 transition-transform shadow-lg flex items-center justify-center text-white"
                        >
                          <Database size={20} />
                        </button>
                        <span className="text-[9px] font-black opacity-60 uppercase">Research</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <button 
                          onClick={() => addShape('training')}
                          className="w-12 h-12 rounded-sm bg-black border-4 border-[#EF4444] hover:scale-110 transition-transform shadow-lg flex items-center justify-center text-white"
                        >
                          <Zap size={20} />
                        </button>
                        <span className="text-[9px] font-black opacity-60 uppercase">Operator</span>
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <button 
                          onClick={() => addShape('deploy')}
                          style={{ clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)' }}
                          className="w-14 h-12 bg-black border-4 border-[#8B5CF6] hover:scale-110 transition-transform shadow-lg flex items-center justify-center text-white"
                        >
                          <Rocket size={20} />
                        </button>
                        <span className="text-[9px] font-black opacity-60 uppercase">Deploy</span>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { id: 'READ_ONLY', color: '#10B981', label: 'Read Only' },
                        { id: 'WRITE_ONLY', color: '#F59E0B', label: 'Write Only' },
                        { id: 'READ_WRITE', color: '#EF4444', label: 'Read/Write' },
                        { id: 'HANDOFF', color: '#8B5CF6', label: 'Handoff' },
                      ].map(link => (
                        <button
                          key={link.id}
                          onClick={() => setSelectedLinkType(link.id)}
                          className={`flex items-center gap-3 p-3 border-2 border-black transition-all ${selectedLinkType === link.id ? 'bg-black text-white' : 'bg-white hover:bg-black/5'}`}
                        >
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: link.color }} />
                          <span className="text-[10px] font-black uppercase tracking-widest">{link.label}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* --- Connection Inspector --- */}
      <AnimatePresence>
        {inspectedConnId && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-12"
            onClick={() => setInspectedConnId(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-[#F2F0EB] text-[#1A1A1A] border-4 border-[#1A1A1A] w-full max-w-2xl overflow-hidden shadow-[20px_20px_0px_0px_rgba(0,0,0,0.3)]"
              onClick={e => e.stopPropagation()}
            >
              <div className="border-b-4 border-[#1A1A1A] p-6 flex justify-between items-center bg-[#1A1A1A] text-white">
                <div className="flex items-center gap-3">
                  <Share2 size={24} />
                  <span className="text-xl font-black uppercase tracking-tighter italic">Connection_Metadata</span>
                </div>
                <button onClick={() => setInspectedConnId(null)} className="hover:scale-110 transition-transform">
                  <X size={24} />
                </button>
              </div>
              
              <div className="p-10 space-y-8">
                <div className="grid grid-cols-2 gap-12">
                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Source_Node</div>
                    <div className="text-2xl font-black tracking-tighter">
                      {shapes.find(s => s.id === connectors.find(c => c.id === inspectedConnId)?.fromId)?.label}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Target_Node</div>
                    <div className="text-2xl font-black tracking-tighter">
                      {shapes.find(s => s.id === connectors.find(c => c.id === inspectedConnId)?.toId)?.label}
                    </div>
                  </div>
                </div>

                <div className="h-px bg-black/10 w-full" />

                <div className="space-y-4">
                  <div className="text-[10px] font-black uppercase opacity-40 italic tracking-widest">Explicit_Explanation</div>
                  <div className="bg-white/50 p-6 border-l-8 border-[#FF4D00] font-mono text-lg leading-relaxed font-bold">
                    {(() => {
                      const conn = connectors.find(c => c.id === inspectedConnId);
                      const m = conn?.metadata;
                      if (!m) return "NO METADATA ASSIGNED_";
                      
                      if (m === 'READ_ONLY') return "INTAKE_AUTHORITY: This connection grants Jotform purely READ-ONLY access to the Airtable state plane. No handoff logic is processed here.";
                      if (m === 'READ_WRITE') return "OPERATOR_AUTHORITY: AntiGravity maintains R/W control over the Airtable state plane. This is the persistent logic layer, not the handoff surface.";
                      if (m === 'HANDOFF') return "SURFACE_HANDOFF: Handoff occurs here via the WordPress socket surface. This bypasses the state plane for direct interface-to-operator communication.";
                      
                      return `CUSTOM_DEFINITION: ${m}`;
                    })()}
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button 
                    onClick={() => setInspectedConnId(null)}
                    className="bg-[#1A1A1A] text-white px-8 py-3 font-black uppercase tracking-widest text-xs hover:bg-[#FF4D00] transition-colors shadow-[4px_4px_0px_0px_#FF4D00]"
                  >
                    Close_Inspector
                  </button>
                </div>
              </div>

              <div className="bg-black/5 p-3 text-[9px] font-black uppercase tracking-[0.2em] flex justify-center opacity-30">
                &copy; 2026 DARCH PROTOCOL // INTERFACE_LAYER_01
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Shape Inspector --- */}
      <AnimatePresence>
        {inspectedShapeId && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-12"
            onClick={() => setInspectedShapeId(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-[#F2F0EB] text-[#1A1A1A] border-4 border-[#1A1A1A] w-full max-w-2xl overflow-hidden shadow-[20px_20px_0px_0px_rgba(0,0,0,0.3)]"
              onClick={e => e.stopPropagation()}
            >
              <div className="border-b-4 border-[#1A1A1A] p-6 flex justify-between items-center bg-[#1A1A1A] text-white">
                <div className="flex items-center gap-3">
                  <Database size={24} />
                  <span className="text-xl font-black uppercase tracking-tighter italic">Module_Manifest</span>
                </div>
                <button onClick={() => setInspectedShapeId(null)} className="hover:scale-110 transition-transform">
                  <X size={24} />
                </button>
              </div>
              
              <div className="p-10 space-y-8">
                <div className="grid grid-cols-3 gap-8">
                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Identity_Initials</div>
                    <div className="text-3xl font-black tracking-tighter text-[#FF4D00]">
                      {shapes.find(s => s.id === inspectedShapeId)?.label.substring(0, 2).toUpperCase()}
                    </div>
                  </div>
                  <div className="space-y-2 col-span-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Identity_Full</div>
                    <div className="text-3xl font-black tracking-tighter uppercase italic">
                      {shapes.find(s => s.id === inspectedShapeId)?.label}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Module_Type</div>
                    <div className="text-xl font-black tracking-tighter opacity-80 uppercase">
                      {(() => {
                        const type = shapes.find(s => s.id === inspectedShapeId)?.type;
                        if (type === 'training') return 'Autonomous Agentic Model';
                        if (type === 'research') return 'State Persistence Engine';
                        if (type === 'ingest') return 'Ingress Data Stream';
                        if (type === 'deploy') return 'Production Handoff Socket';
                        return 'Standard Logic Node';
                      })()}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[10px] font-black uppercase opacity-40">Persistence_Lock</div>
                    <button 
                      onClick={() => toggleLockShape(inspectedShapeId!)}
                      className={`flex items-center gap-2 px-4 py-2 border-2 border-black font-black uppercase text-[10px] transition-all ${shapes.find(s => s.id === inspectedShapeId)?.isLocked ? 'bg-black text-white' : 'bg-white hover:bg-black/5'}`}
                    >
                      {shapes.find(s => s.id === inspectedShapeId)?.isLocked ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
                      {shapes.find(s => s.id === inspectedShapeId)?.isLocked ? "System_Locked" : "System_Unlocked"}
                    </button>
                  </div>
                </div>

                <div className="h-px bg-black/10 w-full" />

                <div className="space-y-4">
                  <div className="text-[10px] font-black uppercase opacity-40 italic tracking-widest">Active_Function_Manifest</div>
                  <div className="grid gap-2">
                    {(() => {
                      const relevantConns = connectors.filter(c => c.fromId === inspectedShapeId || c.toId === inspectedShapeId);
                      if (relevantConns.length === 0) return <div className="text-xs font-bold opacity-30 italic">NO ACTIVE LINKS DETECTED_</div>;
                      
                      return relevantConns.map(c => {
                        const isSource = c.fromId === inspectedShapeId;
                        const otherId = isSource ? c.toId : c.fromId;
                        const otherShape = shapes.find(s => s.id === otherId);
                        const arrow = c.dir === 'both' ? '<=>' : isSource ? '==>' : '<==';
                        
                        return (
                          <div key={c.id} className="flex items-center gap-4 bg-white/50 p-4 border-l-4 border-black font-mono text-sm">
                            <span className="font-black text-[#FF4D00]">{c.metadata || 'LINK'}</span>
                            <span className="opacity-40">{arrow}</span>
                            <span className="font-bold">{otherShape?.label || 'UNKNOWN'}</span>
                            <span className="ml-auto text-[10px] font-black opacity-30">[{c.operation}]</span>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button 
                    onClick={() => setInspectedShapeId(null)}
                    className="bg-[#1A1A1A] text-white px-8 py-3 font-black uppercase tracking-widest text-xs hover:bg-[#FF4D00] transition-colors shadow-[4px_4px_0px_0px_#FF4D00]"
                  >
                    Close_Manifest
                  </button>
                </div>
              </div>

              <div className="bg-black/5 p-3 text-[9px] font-black uppercase tracking-[0.2em] flex justify-center opacity-30">
                &copy; 2026 DARCH PROTOCOL // SYSTEM_KERNEL_LAYER
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

function ToolbarButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center justify-center gap-1 p-2 w-full rounded-lg transition-all ${
        active ? 'bg-[#1A1A1A] text-white shadow-lg' : 'text-[#1A1A1A]/60 hover:bg-[#1A1A1A]/5'
      }`}
    >
      {icon}
      <span className="text-[7px] font-black uppercase tracking-wider">{label}</span>
    </button>
  );
}

function SpecItem({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-baseline">
      <span className="text-[11px] font-black uppercase text-[#1A1A1A]/40 tracking-wider">{label}</span>
      <span className="text-xl font-black text-[#1A1A1A]">{value}</span>
    </div>
  );
}

function ContextItem({ icon, label, onClick, variant = 'default' }: { icon: ReactNode, label: string, onClick: () => void, variant?: 'default' | 'danger' }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-2.5 px-3 py-2 text-sm transition-colors ${
        variant === 'danger' ? 'text-red-500 hover:bg-red-50' : 'text-gray-700 hover:bg-gray-50'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

interface DiagramShapeProps {
  key?: string | number;
  shape: Shape;
  selected: boolean;
  connecting: boolean;
  onMouseDown: (e: ReactMouseEvent) => void;
  onResizeMouseDown: (e: ReactMouseEvent) => void;
  onLabelChange: (val: string) => void;
  onContextMenu: (e: ReactMouseEvent) => void;
  onDoubleClick: () => void;
}

function DiagramShape({ shape, selected, connecting, onMouseDown, onResizeMouseDown, onLabelChange, onContextMenu, onDoubleClick }: DiagramShapeProps) {
  const [isEditing, setIsEditing] = useState(false);
  const colorData = COLORS[shape.color];

  const abbreviation = useMemo(() => {
    return shape.label.substring(0, 2).toUpperCase();
  }, [shape.label]);

  return (
    <div 
      className={`absolute flex items-center justify-center pointer-events-auto transition-all opacity-75 hover:opacity-100 ${
        selected ? 'shadow-[0_0_0_2px_white,0_0_0_4px_#FF4D00] !opacity-100' : ''
      } ${connecting ? 'shadow-[0_0_0_2px_white,0_0_0_4px_#34d399]' : ''}`}
      style={{ 
        left: shape.x, 
        top: shape.y, 
        width: shape.w, 
        height: shape.h,
        cursor: 'grab' 
      }}
      onMouseDown={onMouseDown}
      onContextMenu={onContextMenu}
      onDoubleClick={onDoubleClick}
    >
      {shape.type === 'deploy' ? (
        <div 
          style={{ 
            clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)',
            borderColor: colorData.hex,
            borderWidth: '4px',
            borderStyle: 'solid'
          }} 
          className={`absolute inset-0 bg-black shadow-sm transition-colors ${connecting ? 'marching-ants' : ''}`} 
        />
      ) : shape.type === 'training' ? (
        <div 
          style={{ 
            borderColor: colorData.hex,
            borderWidth: '4px',
            borderStyle: 'solid'
          }}
          className={`absolute inset-0 bg-black rounded-sm shadow-sm transition-colors ${connecting ? 'marching-ants' : ''}`} 
        />
      ) : (
        <div 
          style={{ 
            borderColor: colorData.hex,
            borderWidth: '4px',
            borderStyle: 'solid'
          }}
          className={`absolute inset-0 bg-black shadow-sm transition-colors ${shape.type === 'ingest' ? 'rounded-full' : 'rounded-md'} ${connecting ? 'marching-ants' : ''}`} 
        />
      )}

      {isEditing ? (
        <textarea
          autoFocus
          className="relative z-10 w-[80%] bg-transparent border-none outline-none text-center text-[10px] uppercase font-black tracking-wider resize-none text-white"
          value={shape.label}
          onChange={(e) => onLabelChange(e.target.value)}
          onBlur={() => setIsEditing(false)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); setIsEditing(false); } }}
        />
      ) : (
        <div className="relative z-10 text-[10px] uppercase font-black tracking-widest text-center px-2 overflow-hidden text-ellipsis whitespace-nowrap pointer-events-none text-white">
          {shape.type === 'training' ? shape.label : abbreviation}
        </div>
      )}

      {/* Resize Handle */}
      {selected && shape.type !== 'deploy' && shape.type !== 'training' && shape.type !== 'ingest' && (
        <div 
          className="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-[#FF4D00] rounded-none cursor-se-resize z-20"
          onMouseDown={onResizeMouseDown}
        />
      )}

      {/* Ports */}
      <Port side="top" color={connecting ? '#34d399' : TOKENS.UI.TEXT_CSS} />
      <Port side="bottom" color={connecting ? '#34d399' : TOKENS.UI.TEXT_CSS} />
      <Port side="left" color={connecting ? '#34d399' : TOKENS.UI.TEXT_CSS} />
      <Port side="right" color={connecting ? '#34d399' : TOKENS.UI.TEXT_CSS} />

      {shape.isLocked && (
        <div className="absolute top-1 right-1 text-white bg-black/50 rounded-full p-0.5 pointer-events-none">
          <Minimize2 size={8} />
        </div>
      )}
    </div>
  );
}

function Port({ side, color }: { side: 'top' | 'bottom' | 'left' | 'right', color?: string }) {
  const positionClass = {
    top: '-top-1.5 left-1/2 -translate-x-1/2',
    bottom: '-bottom-1.5 left-1/2 -translate-x-1/2',
    left: '-left-1.5 top-1/2 -translate-y-1/2',
    right: '-right-1.5 top-1/2 -translate-y-1/2',
  };

  return (
    <div 
      className={`absolute w-3 h-3 border-2 border-white rounded-full opacity-0 hover:opacity-100 transition-opacity cursor-crosshair z-30 ${positionClass[side]}`} 
      style={{ backgroundColor: color || TOKENS.UI.TEXT_CSS }}
    />
  );
}
