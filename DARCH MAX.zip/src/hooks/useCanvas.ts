import { MouseEvent, TouchEvent, useState, useCallback, useEffect, useRef } from 'react';

export interface Point {
  x: number;
  y: number;
}

export function useCanvas() {
  const [pan, setPan] = useState<Point>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    setZoom((prevZoom) => {
      const newZoom = Math.min(3, Math.max(0.25, prevZoom * delta));
      setPan((prevPan) => ({
        x: mx - (mx - prevPan.x) * (newZoom / prevZoom),
        y: my - (my - prevPan.y) * (newZoom / prevZoom),
      }));
      return newZoom;
    });
  }, []);

  const handleMouseDown = useCallback((e: MouseEvent) => {
    if (e.button !== 1 && (e.button !== 0 || e.target !== containerRef.current)) return;

    const startX = e.clientX - pan.x;
    const startY = e.clientY - pan.y;

    const handleMouseMove = (moveEvent: globalThis.MouseEvent) => {
      setPan({
        x: moveEvent.clientX - startX,
        y: moveEvent.clientY - startY,
      });
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  }, [pan]);

  useEffect(() => {
    const el = containerRef.current;
    if (el) {
      el.addEventListener('wheel', handleWheel, { passive: false });
      return () => el.removeEventListener('wheel', handleWheel);
    }
  }, [handleWheel]);

  return {
    pan,
    zoom,
    containerRef,
    handleMouseDown,
    setPan,
    setZoom
  };
}
