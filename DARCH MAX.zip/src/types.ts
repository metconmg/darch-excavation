export type ShapeType = 'research' | 'ingest' | 'training' | 'deploy';
export type DirectionType = 'forward' | 'both' | 'association';
export type EdgeOperation = 'CONNECT' | 'MERGE' | 'APPEND' | 'OVERRIDE';
export type EdgeState = 'PENDING' | 'ACTIVE' | 'ERROR';

export type ColorType = 'blue' | 'green' | 'red' | 'purple' | 'amber';

/**
 * .dag Serialization Contract
 * Standardizes spatial metadata into a portable logic ledger.
 */
export interface DagManifest {
  version: string;
  engineStatus: 'NOMINAL' | 'DEGRADED' | 'FAILURE';
  nodes: {
    id: string;
    type: ShapeType;
    label: string;
    contract: {
      color: ColorType;
    };
    spatial: {
      x: number;
      y: number;
      w: number;
      h: number;
    };
  }[];
  edges: {
    id: string;
    source: string;
    target: string;
    config: {
      direction: DirectionType;
      operation: EdgeOperation;
      state: EdgeState;
      sourceBinding?: string;
      targetBinding?: string;
    };
  }[];
  timestamp: string;
}

export interface Shape {
  id: string;
  type: ShapeType;
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  color: ColorType;
  isLocked?: boolean;
}

export interface Connector {
  id: string;
  fromId: string;
  toId: string;
  dir: DirectionType;
  operation: EdgeOperation;
  state: EdgeState;
  sourceBinding?: string;
  targetBinding?: string;
  errorMessage?: string;
  metadata?: string;
}

export type Tool = 'select' | 'connect' | 'research' | 'ingest' | 'training' | 'deploy';

/**
 * SEMANTIC TOKENS (Manifest Compliance)
 * Decouples stylistic intent from implementation logic.
 */
export const TOKENS = {
  UI: {
    CANVAS_BG: '#F2F0EB',
    PANEL_BG: 'rgba(255, 255, 255, 0.3)',
    BORDER_CSS: 'rgba(26, 26, 26, 0.1)',
    HIGHLIGHT_CSS: '#FF4D00',
    TEXT_CSS: '#1A1A1A',
  },
  NODES: {
    DEFAULT_W: 60,
    DEFAULT_H: 44,
    DIAMOND_SIZE: 120,
    PARALLELOGRAM_W: 70,
    PORT_RADIUS: 6,
    BORDER_WIDTH: 4,
  },
  EDGES: {
    STROKE_WIDTH: 1,
    ACTIVE_STROKE_WIDTH: 2,
    OPACITY: 0.6,
  }
};

export const COLORS: Record<ColorType, { bg: string, border: string, text: string, hex: string }> = {
  blue: { bg: 'bg-[#3B82F6]', border: 'border-transparent', text: 'text-white', hex: '#3B82F6' },
  green: { bg: 'bg-[#10B981]', border: 'border-transparent', text: 'text-white', hex: '#10B981' },
  red: { bg: 'bg-[#EF4444]', border: 'border-transparent', text: 'text-white', hex: '#EF4444' },
  purple: { bg: 'bg-[#8B5CF6]', border: 'border-transparent', text: 'text-white', hex: '#8B5CF6' },
  amber: { bg: 'bg-[#F59E0B]', border: 'border-transparent', text: 'text-white', hex: '#F59E0B' }
};
